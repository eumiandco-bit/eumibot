import discord
from discord import app_commands
from discord.ext import commands
import datetime
import json
import os

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)
tree = bot.tree

# ================== UPDATED CHANNEL ID ==================
TASK_POOL_CHANNEL_ID = 1488866118776127688      # ← New Task Pool Channel
MONITORING_LOG_CHANNEL_ID = 1487651738998800414

DATA_FILE = "task_data.json"

# ====================== HELPER FUNCTIONS ======================
def load_task_counter():
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r") as f:
                data = json.load(f)
                return data.get("last_task_id", 0)
        except:
            return 0
    return 0

def save_task_counter(task_id):
    with open(DATA_FILE, "w") as f:
        json.dump({"last_task_id": task_id}, f)

last_task_id = load_task_counter()

def get_next_task_id():
    global last_task_id
    last_task_id += 1
    save_task_counter(last_task_id)
    return f"{last_task_id:03d}"

def get_priority_emoji(priority: str):
    if priority == "Urgent": return "🔴"
    elif priority == "High": return "🟠"
    elif priority == "Medium": return "🔵"
    else: return "🟢"

def get_priority_color(priority: str):
    if priority == "Urgent": return 0xFF0000      # Red
    elif priority == "High": return 0xFF8800      # Orange
    elif priority == "Medium": return 0x00BFFF    # Deep Sky Blue
    else: return 0x00CC66                         # Green

def get_deadline(priority: str):
    now = datetime.datetime.now(datetime.timezone.utc)
    if priority == "Urgent":
        return now + datetime.timedelta(hours=12)
    elif priority == "High":
        return now + datetime.timedelta(hours=24)
    elif priority == "Medium":
        return now + datetime.timedelta(hours=48)
    else:  # Low
        return now + datetime.timedelta(days=3)

# ====================== TASK CLAIM VIEW ======================
class TaskClaimView(discord.ui.View):
    def __init__(self, task_id: str, task_name: str, details: str, notes: str, priority: str, creator: discord.Member):
        super().__init__(timeout=None)
        self.task_id = task_id
        self.task_name = task_name
        self.details = details
        self.notes = notes
        self.priority = priority
        self.creator = creator
        self.claimed_by = None
        self.thread = None
        self.deadline = get_deadline(priority)
        self.created_at = datetime.datetime.now(datetime.timezone.utc)

    @discord.ui.button(label="CLAIM TASK", style=discord.ButtonStyle.primary, emoji="🔵", custom_id="claim_task")
    async def claim(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.claimed_by:
            await interaction.response.send_message("❌ THIS TASK HAS ALREADY BEEN CLAIMED!", ephemeral=True)
            return

        await interaction.response.defer()
        self.claimed_by = interaction.user

        task_pool = interaction.guild.get_channel(TASK_POOL_CHANNEL_ID)
        thread_name = f"TASK-{self.task_id}-{self.task_name[:40].upper().replace(' ', '-')}"
        
        self.thread = await task_pool.create_thread(
            name=thread_name,
            message=interaction.message,
            auto_archive_duration=4320
        )

        await self.thread.send(f"📁 **TASK #{self.task_id} THREAD**\nALL FILES, PROOFS, AND DISCUSSIONS SHOULD GO HERE.")

        embed = self.create_in_progress_embed()
        view = InProgressView(self.task_id, self.task_name, self.details, self.notes, self.claimed_by, self.priority, self.thread, self.deadline)
        
        await interaction.message.edit(embed=embed, view=view)

    def create_in_progress_embed(self):
        deadline_ts = int(self.deadline.timestamp())
        created_ts = int(self.created_at.timestamp())
        
        embed = discord.Embed(title=f"IN PROGRESS • #{self.task_id}", color=get_priority_color(self.priority))
        embed.add_field(name="TASK NAME", value=self.task_name.upper(), inline=False)
        
        if self.details:
            embed.add_field(name="DETAILS", value=self.details, inline=False)
        if self.notes:
            embed.add_field(name="NOTES", value=self.notes, inline=False)

        embed.add_field(name="CLAIMED BY", value=self.claimed_by.mention, inline=True)
        embed.add_field(name="PRIORITY", value=f"{get_priority_emoji(self.priority)} {self.priority.upper()}", inline=True)
        embed.add_field(name="DEADLINE", value=f"<t:{deadline_ts}:R> (<t:{deadline_ts}:f>)", inline=False)
        embed.add_field(name="CREATED", value=f"<t:{created_ts}:f>", inline=False)
        embed.add_field(name="STATUS", value="IN PROGRESS", inline=False)

        if self.thread:
            embed.add_field(name="THREAD", value=self.thread.mention, inline=False)

        embed.set_footer(text=f"CREATED BY {self.creator.display_name.upper()}")
        return embed


# ====================== IN PROGRESS VIEW ======================
class InProgressView(discord.ui.View):
    def __init__(self, task_id: str, task_name: str, details: str, notes: str, claimed_by: discord.Member, priority: str, thread, deadline):
        super().__init__(timeout=None)
        self.task_id = task_id
        self.task_name = task_name
        self.details = details
        self.notes = notes
        self.claimed_by = claimed_by
        self.priority = priority
        self.thread = thread
        self.deadline = deadline

    def is_allowed(self, user: discord.Member):
        return user.id == self.claimed_by.id or user.guild_permissions.manage_messages

    @discord.ui.button(label="MARK AS DONE", style=discord.ButtonStyle.green, emoji="✅", custom_id="mark_done")
    async def done(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.is_allowed(interaction.user):
            await interaction.response.send_message("❌ ONLY THE CLAIMANT OR ADMIN CAN MARK THIS AS DONE.", ephemeral=True)
            return

        await interaction.response.defer()
        await interaction.message.delete()

        monitoring = interaction.guild.get_channel(MONITORING_LOG_CHANNEL_ID)
        if monitoring:
            embed = discord.Embed(title=f"TASK COMPLETED • #{self.task_id}", description=self.task_name.upper(), color=0x00FF9D)
            embed.add_field(name="CLAIMED BY", value=self.claimed_by.mention, inline=True)
            embed.add_field(name="COMPLETED BY", value=interaction.user.mention, inline=True)
            embed.add_field(name="COMPLETED ON", value=f"<t:{int(datetime.datetime.now(datetime.timezone.utc).timestamp())}:F>", inline=False)
            if self.thread:
                embed.add_field(name="THREAD", value=self.thread.mention, inline=False)
            await monitoring.send(embed=embed)

        if self.thread:
            summary = discord.Embed(title="✅ TASK COMPLETED", description=self.task_name.upper(), color=0x00FF9D)
            summary.add_field(name="COMPLETED BY", value=interaction.user.mention, inline=False)
            await self.thread.send(embed=summary)

    @discord.ui.button(label="CANCEL TASK", style=discord.ButtonStyle.red, emoji="❌", custom_id="cancel_task")
    async def cancelled(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.is_allowed(interaction.user):
            await interaction.response.send_message("❌ ONLY THE CLAIMANT OR ADMIN CAN CANCEL THIS TASK.", ephemeral=True)
            return

        await interaction.response.defer()
        await interaction.message.delete()

        monitoring = interaction.guild.get_channel(MONITORING_LOG_CHANNEL_ID)
        if monitoring:
            embed = discord.Embed(title=f"TASK CANCELLED • #{self.task_id}", description=self.task_name.upper(), color=0xFF4D4D)
            embed.add_field(name="CANCELLED BY", value=interaction.user.mention, inline=False)
            embed.add_field(name="TIME", value=f"<t:{int(datetime.datetime.now(datetime.timezone.utc).timestamp())}:F>", inline=False)
            await monitoring.send(embed=embed)


# ====================== REOPEN COMMAND ======================
@tree.command(name="reopentask", description="REOPEN A COMPLETED TASK (ADMIN ONLY)")
@app_commands.describe(
    task_id="TASK ID TO REOPEN (e.g. 046)",
    reason="REASON FOR REOPENING THE TASK"
)
async def reopentask(interaction: discord.Interaction, task_id: str, reason: str):
    if not interaction.user.guild_permissions.manage_messages:
        await interaction.response.send_message("❌ THIS COMMAND IS FOR ADMINS ONLY.", ephemeral=True)
        return

    await interaction.response.defer(ephemeral=True)

    task_pool = interaction.guild.get_channel(TASK_POOL_CHANNEL_ID)
    if not task_pool:
        await interaction.followup.send("❌ TASK POOL CHANNEL NOT FOUND!", ephemeral=True)
        return

    embed = discord.Embed(title=f"IN PROGRESS • #{task_id}", color=0xFF8800)
    embed.add_field(name="TASK NAME", value="REOPENED TASK", inline=False)
    embed.add_field(name="DETAILS", value="THIS TASK WAS PREVIOUSLY COMPLETED AND HAS BEEN REOPENED.", inline=False)
    embed.add_field(name="REOPEN REASON", value=reason, inline=False)
    embed.add_field(name="REOPENED BY", value=interaction.user.mention, inline=False)
    embed.add_field(name="STATUS", value="IN PROGRESS - REOPENED", inline=False)

    message = await task_pool.send(embed=embed)

    # Reuse existing thread
    existing_thread = None
    for thread in task_pool.threads:
        if thread.name.startswith(f"TASK-{task_id}-"):
            existing_thread = thread
            break

    if not existing_thread:
        async for thread in task_pool.archived_threads(limit=100):
            if thread.name.startswith(f"TASK-{task_id}-"):
                existing_thread = thread
                await existing_thread.edit(archived=False)
                break

    if existing_thread:
        thread = existing_thread
        await thread.send(f"🔄 **TASK #{task_id} REOPENED**\n**Reason:** {reason}\n**Reopened by:** {interaction.user.mention}")
    else:
        thread_name = f"TASK-{task_id}-REOPENED"
        thread = await task_pool.create_thread(name=thread_name, message=message, auto_archive_duration=4320)
        await thread.send(f"🔄 **TASK #{task_id} REOPENED**\n**Reason:** {reason}\n**Reopened by:** {interaction.user.mention}")

    view = InProgressView(task_id, "REOPENED TASK", "Reopened task", reason, interaction.user, "High", thread, datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=24))
    await message.edit(view=view)

    monitoring = interaction.guild.get_channel(MONITORING_LOG_CHANNEL_ID)
    if monitoring:
        log = discord.Embed(title=f"TASK REOPENED • #{task_id}", color=0xFFAA00)
        log.add_field(name="REASON", value=reason, inline=False)
        log.add_field(name="REOPENED BY", value=interaction.user.mention, inline=False)
        await monitoring.send(embed=log)

    await interaction.followup.send(f"✅ TASK #{task_id} HAS BEEN REOPENED SUCCESSFULLY!", ephemeral=True)


# ====================== /NEWTASK ======================
@tree.command(name="newtask", description="CREATE A NEW TASK")
@app_commands.describe(
    task_name="TASK NAME",
    priority="PRIORITY LEVEL",
    details="DETAILS OF THE TASK",
    notes="ADDITIONAL NOTES (OPTIONAL)"
)
@app_commands.choices(priority=[
    app_commands.Choice(name="🔴 Urgent (12 hrs)", value="Urgent"),
    app_commands.Choice(name="🟠 High (24 hrs)", value="High"),
    app_commands.Choice(name="🔵 Medium (32 hrs)", value="Medium"),
    app_commands.Choice(name="🟢 Low (42 hrs)", value="Low")
])
async def newtask(
    interaction: discord.Interaction,
    task_name: str,
    priority: app_commands.Choice[str],
    details: str = "",
    notes: str = ""
):
    await interaction.response.defer(ephemeral=True)

    task_pool = interaction.guild.get_channel(TASK_POOL_CHANNEL_ID)
    if not task_pool:
        await interaction.followup.send("❌ TASK POOL CHANNEL NOT FOUND!", ephemeral=True)
        return

    task_id = get_next_task_id()
    deadline = get_deadline(priority.value)
    deadline_ts = int(deadline.timestamp())
    created_ts = int(datetime.datetime.now(datetime.timezone.utc).timestamp())

    embed = discord.Embed(title=f"NEW TASK • #{task_id}", color=get_priority_color(priority.value))
    embed.add_field(name="TASK NAME", value=task_name.upper(), inline=False)
    
    if details:
        embed.add_field(name="DETAILS", value=details, inline=False)
    if notes:
        embed.add_field(name="NOTES", value=notes, inline=False)

    embed.add_field(name="PRIORITY", value=f"{get_priority_emoji(priority.value)} {priority.value.upper()}", inline=True)
    embed.add_field(name="DEADLINE", value=f"<t:{deadline_ts}:R> (<t:{deadline_ts}:f>)", inline=False)
    embed.add_field(name="CREATED", value=f"<t:{created_ts}:f>", inline=False)
    embed.add_field(name="STATUS", value="AVAILABLE TO CLAIM", inline=False)

    view = TaskClaimView(task_id, task_name, details, notes, priority.value, interaction.user)

    await task_pool.send(embed=embed, view=view)
    await interaction.followup.send(f"✅ TASK #{task_id} HAS BEEN CREATED!", ephemeral=True)


@bot.event
async def on_ready():
    print(f"✅ BOT IS ONLINE AS {bot.user}")
    try:
        await tree.sync()
        print("✅ SLASH COMMANDS SYNCED!")
    except Exception as e:
        print(f"Sync error: {e}")

bot.run("MTQ4NzYxNDE0MDU4MjQ2MTQ0MA.GdtK4O.uF9D6fQdEWE0L2IwOGqddnXxYx5GsNNKstbFP0")